import React from "react";

const Tempe = props =>(
  
    <p className="weather__key">Temperature 
	<span className="weather__value">{ props.temperature }</span></p>
);

export default Tempe;